import os
import pyperclip
import pyautogui
import keyboard
from tkinter import ttk
import tkinter as tk
import threading
import time
from tkinter import messagebox
import pystray
from PIL import Image
from pystray import MenuItem as item, Menu

def on_left_click():
    root.deiconify()

def withdraw_window():  
    root.withdraw()

def select_func():
    try:
        keyboard.unhook_all_hotkeys()
    except:
        pass
    if enabled.get() == 1:
        selection_tran = combobox_tran.get()
        selection_up = combobox_up.get()
        selection_lw = combobox_lw.get()
        selection_bw = combobox_bw.get()
        try:
            keyboard.add_hotkey(selection_tran,ktg)
            keyboard.add_hotkey(selection_lw,lower_func)
            keyboard.add_hotkey(selection_up,upper_func)
            keyboard.add_hotkey(selection_bw, backward_func)
            messagebox.showinfo('Информация','Клавиши успешно назначены!')
        except:
            messagebox.showerror('Ошибка','Ошибка назначения клавиш!')
    else:
        selection_tran = combobox_tran.get()
        try:
            keyboard.add_hotkey(selection_tran,ktg)
            messagebox.showinfo('Информация','Клавиши успешно назначены!')
        except:
            messagebox.showerror('Ошибка','Ошибка назначения клавиш!')
    return

def exit_func():
    os.abort()
    



    



def Tk_func():
    
    global root

    root = tk.Tk()
    root.title('Let.Swap')
    root.geometry("350x350")
    
    keys_tran = ["alt+z", "ctrl+alt+z"]
    keys_up = ["alt+x", "ctrl+alt+x"]
    keys_lw = ["alt+q", "ctrl+alt+q"]
    keys_bw = ["alt+b", "ctrl+alt+b"]

    global combobox_tran,combobox_up,combobox_lw,combobox_bw,button_check,enabled

    enabled = tk.IntVar()

    ttk.Label(text='Выбор сочетания клавиш для траслитерации').pack()
    combobox_tran = ttk.Combobox(values=keys_tran)
    combobox_tran.pack(padx=75,pady=6)

    
    button_check = ttk.Checkbutton(text='Доп функции',variable=enabled)
    button_check.pack()
    
    ttk.Label(text='Выбор сочетания клавиш для в. регистра').pack()
    combobox_up= ttk.Combobox(values=keys_up)
    combobox_up.pack(padx=76,pady=6)
    
    ttk.Label(text='Выбор сочетания клавиш для н. регистра').pack()
    combobox_lw= ttk.Combobox(values=keys_lw)
    combobox_lw.pack(padx=76,pady=6)

    ttk.Label(text='Выбор сочетания клавиш для обратного регистра').pack()
    combobox_bw= ttk.Combobox(values=keys_bw)
    combobox_bw.pack(padx=76,pady=6)
    
    btn = ttk.Button(text='Применить',command=select_func)
    btn2 = ttk.Button(text='Выход',command=exit_func)
    
    
    btn.pack(padx=6,pady=6)
    btn2.pack(padx=6,pady=6)


    root.protocol('WM_DELETE_WINDOW', withdraw_window)
    root.mainloop()

def create_image(width, height):
    image = Image.open('icon.ico')

    return image
    
d={'-':'-','q':'й','w':'ц','e':'у','r':'к','t':'е','y':'н','u':'г','i':'ш','o':'щ',
   'p':'з','[':'х',']':'ъ','a':'ф','s':'ы','d':'в','f':'а','g':'п','h':'р',
   'j':'о','k':'л','l':'д',';':'ж',"'":'э','z':'я','x':'ч','c':'с','v':'м',
   'b':'и','n':'т','m':'ь',',':'б','/':'.','!':'!','@':'"','#':'№',
   '$':';','%':'%','^':':','*':'*','(':'(',')':')','_':'_','+':'+',
   '|':'|','~':'Ё','`':'ё','Q':'Й','W':'Ц','E':'У','R':'К','T':'Е','Y':'Н',
   'U':'Г','I':'Ш','O':'Щ','P':'З','{':'Х','}':'Ъ','A':'Ф','S':'Ы','D':'В',
   'F':'А','G':'П','H':'Р','J':'О','K':'Л','L':'Д',':':'Ж','"':'Э','Z':'Я',
   'X':'Ч','C':'С','V':'М','B':'И','N':'Т','M':'Ь','<':'Б','>':'Ю','?':',',
   'й': 'q', 'ц': 'w', 'у': 'e', 'к': 'r', 'е': 't', 'н': 'y', 'г': 'u',
   'ш': 'i', 'щ': 'o', 'з': 'p', 'х': '[', 'ъ': ']','ф': 'a', 'ы': 's',
   'в': 'd', 'а': 'f', 'п': 'g', 'р': 'h', 'о': 'j', 'л': 'k', 'д': 'l',
   'ж': ';', 'э': "'",'я': 'z', 'ч': 'x', 'с': 'c','м': 'v', 'и': 'b',
   'т': 'n', 'ь': 'm', 'б': ',', 'ю': '.', '!': '!', '"': '@',
   '№': '#', ';': 'ж', '%': '%', ':': '^', '?': ',', '*': '*', '(': '(',
   ')': ')', '_': '_', '+': '+', '|': '|', 'Ё': '~', 'ё': '`','Й': 'Q',
   'Ц': 'W', 'У': 'E', 'К': 'R', 'Е': 'T', 'Н': 'Y', 'Г': 'U', 'Ш': 'I',
   'Щ': 'O', 'З': 'P', 'Х': '{', 'Ъ': '}','Ф': 'A', 'Ы': 'S', 'В': 'D',
   'А': 'F', 'П': 'G', 'Р': 'H', 'О': 'J', 'Л': 'K', 'Д': 'L', 'Ж': ':',
   'Э': '"','Я': 'Z', 'Ч': 'X', 'С': 'C', 'М': 'V', 'И': 'B', 'Т': 'N',
   'Ь': 'M', 'Б': '<', 'Ю': '>', ',': '?', ' ': ' ','1':'1','2':'2','3':'3',
   '4':'4','5':'5','6':'6','7':'7','8':'8','9':'9','0':'0','&':'?'}
alphabet = ["а","б","в","г","д","е","ё","ж","з","и","й","к","л","м","н","о",
            "п","р","с","т","у","ф","х","ц","ч","ш","щ","ъ","ы","ь","э","ю","я"]
def mainn():
    pyautogui.hotkey('ctrl','c')
    a = pyperclip.paste()
    if a == '/exit/':
        pass
    #    sys.exit()
    else:
        aa = list(a)
        bb = []
        string = ''
        #print(aa)
        for i in range(len(aa)):
            if aa[i] == '.':
                if (aa[i - 1]) in alphabet:
                    aa[i] = 'ю'
                else:
                    if (aa[i + 1]) in alphabet:
                        aa[i] = '/'
                    else:
                        aa[i] = 'ю'
                bb.append(aa[i])
            elif aa[i] == ',':
                if (aa[i - 1]) in alphabet:
                    aa[i] = 'б'
                else:
                    if (aa[i + 1]) in alphabet:
                        aa[i] = '?'
                    else:
                        aa[i] = 'б'
                bb.append(aa[i])
            else:
                if aa[i] in d:
                    aa[i] = d.get(aa[i])
                    bb.append(aa[i])
        #print(bb)
        for el in bb:
            string += el
        print(string)
        pyperclip.copy(string)
        pyautogui.hotkey('ctrl','v')
        return
def mainn_2():
    pyautogui.hotkey('ctrl','c')
    a = pyperclip.paste()
    b = a.upper()
    pyperclip.copy(b)
    pyautogui.hotkey('ctrl','v')
    return
def mainn_3():
    pyautogui.hotkey('ctrl','c')
    a = pyperclip.paste()
    b = a.lower()
    pyperclip.copy(b)
    pyautogui.hotkey('ctrl','v')
    return
def mainn_4():
    pyautogui.hotkey('ctrl','c')
    a = pyperclip.paste()
    aa = list(a)
    bb = []
    string = ''
    for i in range(len(aa)):
        if(aa[i].isupper()):
            bb.append(aa[i].lower())
        elif (aa[i].islower()):
            bb.append(aa[i].upper())
        else:
            bb.append(aa[i])
    for el in bb:
        string += el
    print(string)
    pyperclip.copy(string)
    pyautogui.hotkey('ctrl','v')
    return
def ktg():
    time.sleep(0.2)
    mainn()
def upper_func():
    time.sleep(0.2)
    mainn_2()
def lower_func():
    time.sleep(0.2)
    mainn_3()
def backward_func():
    time.sleep(0.2)
    mainn_4()

def ff():
    menu = Menu(item('Открыть',on_left_click))
    icon = pystray.Icon("test_icon", create_image(64, 64), "Заголовок", menu)
    icon.run()
    

thread_1 = threading.Thread(target=Tk_func)
thread_1.start()
thread_2 = threading.Thread(target=ff)
thread_2.start()
